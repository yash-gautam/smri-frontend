import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-tool-card',
  templateUrl: './new-tool-card.component.html',
  styleUrls: ['./new-tool-card.component.css']
})
export class NewToolCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
